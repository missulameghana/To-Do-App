package com.example.nav.ui.gallery;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.nav.DataNote;
import com.example.nav.DbHelper;
import com.example.nav.Dbtasks;
import com.example.nav.Edittask;
import com.example.nav.MainActivity;
import com.example.nav.R;
import com.example.nav.pickadate;
import com.example.nav.ui.home.HomeFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.content.ContentValues.TAG;

class Global{
    static int previousExpandedPosition = -1;
}

public class GalleryFragment extends Fragment {
    private static final String TAG = GalleryFragment.class.getSimpleName();
    private GalleryViewModel galleryViewModel;
    private TextView mTextViewEmpty;
    private RecyclerView mRecyclerView;
    private ListAdapter mListadapter;
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    java.util.Date date = new Date();
    private String Date=dateFormat.format(date);
    private String format_date(String s){
        if(s.charAt(0) == '0'){
            s = s.substring(1);
        }
        return s;

    }
    //private String Date="31-12-2019";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.fragment_gallery);
        setHasOptionsMenu(true);
    }
//    @Override
//    public void onPrepareOptionsMenu(Menu menu) {
//        MenuItem item=menu.findItem(R.id.action_settings);
//        if(item!=null)
//            item.setVisible(false);
//    }

    private Menu menu=null;
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {


//        this.menu=menu;
//        menu.findItem(R.id.action_settings).setVisible(false);
//        getActivity().invalidateOptionsMenu();
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.main1, menu);
//        MenuItem item=menu.findItem(R.id.action_settings);
//        item.setVisible(false);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

//            case R.id.action_settings:
//                // Do onlick on menu action here
//                return false;
            case R.id.gallery_settings:
                Intent intent = new Intent(getActivity(),pickadate.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
        //return false;
        //int id = item.getItemId();

        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            Intent intent = new Intent(getActivity(),pickadate.class);
//            startActivity(intent);
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //setHasOptionsMenu(true);
        //MainActivity.item1.setVisible(false);
        Log.d(TAG, Date);
        Date = format_date(Date);
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        //if(pickadate.btnDatePicker!=null){
        //pickadate.btnDatePicker.setVisibility(View.GONE);
    //}
        mRecyclerView = (RecyclerView) root.findViewById(R.id.recyclerViewdate);
        mTextViewEmpty = (TextView)root.findViewById(R.id.text_gallery);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        DbHelper mHelper=new DbHelper(getActivity());
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String [] columns={Dbtasks.MenuEntry._ID,"name","description","scheduled"};
        Cursor cursor=db.query("tasks",columns,null,null,null,null,null);
        ArrayList data = new ArrayList<DataNote>();
        while(cursor.moveToNext()) {
            int index;
            index = cursor.getColumnIndexOrThrow("scheduled");
            String date = cursor.getString(index);
            String path = "Zen/";

            if(date==null){
                date="";
            }
            if(date.equals(Date)){
                Log.d(TAG,date);

                index = cursor.getColumnIndexOrThrow("name");
                String title = cursor.getString(index);

                index = cursor.getColumnIndexOrThrow("description");
                String description = cursor.getString(index);
                if(!(title.equals("Zen"))){
                    path=path+title;
//                    Log.d(TAG,path);
                }
                String path1=path+"/";
                data.add(new DataNote(title,description,date,path,"tasks"));
                index = cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
                Integer id = cursor.getInt(index);
                //ArrayList<String> subtask=new ArrayList<>();
                //ArrayList<Integer> subtask_id=new ArrayList<>();
                String [] columnssub={Dbtasks.MenuEntry._ID,"name","description","scheduled"};
                //Cursor cursor2 = db.rawQuery("SELECT * FROM subtasks WHERE scheduled="+Date, null);
                Cursor cursor2=db.query("subtasks",columnssub,Dbtasks.MenuEntry.TASK_ID + "=" + id,null,null,null,null);
                while(cursor2.moveToNext()){
                    int index2;
                    index2 = cursor2.getColumnIndexOrThrow("scheduled");
                    String date1 = cursor2.getString(index2);
                    index2 = cursor2.getColumnIndexOrThrow("name");
                    String title1 = cursor2.getString(index2);
                    index2 = cursor2.getColumnIndexOrThrow("description");
                    String description1 = cursor2.getString(index2);
                    if(date1==null){
                        path1=path1+title1;
                        data.add(new DataNote(title1,description1,date1,path1,"subtasks"));
                    }
                    else if(date1.equals(Date)){
                        path1=path1+title1;
                        data.add(new DataNote(title1,description1,date1,path1,"subtasks"));
                    } //handle null date case
                }
                cursor2.close();
                //index2 = cursor2.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
                //subtask_id.add(cursor2.getInt(index2));
                //index2 = cursor2.getColumnIndexOrThrow("name");
                //subtask.add(cursor2.getString(index2));

            }
            else{
                index = cursor.getColumnIndexOrThrow("name");
                String title = cursor.getString(index);
                String path1=path+title+"/";
                index = cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
                Integer id = cursor.getInt(index);
                //ArrayList<String> subtask=new ArrayList<>();
                //ArrayList<Integer> subtask_id=new ArrayList<>();
                String [] columnssub={Dbtasks.MenuEntry._ID,"name","description","scheduled"};
                //Cursor cursor2 = db.rawQuery("SELECT * FROM subtasks WHERE scheduled="+Date, null);
                Cursor cursor2=db.query("subtasks",columnssub,Dbtasks.MenuEntry.TASK_ID + "=" + id,null,null,null,null);
                while(cursor2.moveToNext()){
                    int index2;
                    index2 = cursor2.getColumnIndexOrThrow("scheduled");
                    String date1 = cursor2.getString(index2);
                    index2 = cursor2.getColumnIndexOrThrow("name");
                    String title1 = cursor2.getString(index2);
                    index2 = cursor2.getColumnIndexOrThrow("description");
                    String description1 = cursor2.getString(index2);
                    if(date1==null){
                        date1="";
                    }
                    if(date1.equals(Date)){
                        path1=path1+title1;
                        data.add(new DataNote(title1,description1,date1,path1,"subtasks"));
                    }
                }
                cursor2.close();
            }
            //... do something with data
        }
        db.close();
        cursor.close();
        // RecyclerView rv = (RecyclerView)findViewById(R.id.rv);
//        galleryViewModel.getText().observe(this, new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        mListadapter = new ListAdapter(data);
        mRecyclerView.setAdapter(mListadapter);

        return root;
    }
    public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder>
    {
        private ArrayList<DataNote> dataList;
        private int mExpandedPosition=-1;

        //private String description;
        public ListAdapter(ArrayList<DataNote> data)
        {
            this.dataList = data;
        }

        public class ViewHolder extends RecyclerView.ViewHolder
        {
            TextView textViewText;
            //TextView description;
            TextView textViewComment;
            TextView textViewDate;
            TextView hier;
            Button edit_btn;
            //Button date_picker;

            public ViewHolder(View itemView)
            {
                super(itemView);
                this.textViewText = (TextView) itemView.findViewById(R.id.person_name);
                // this.descrip= (TextView) itemView.findViewById(R.id.text_gallery);
                this.edit_btn = (Button) itemView.findViewById(R.id.edit);
                this.hier = (TextView) itemView.findViewById(R.id.path);
                this.textViewComment = (TextView) itemView.findViewById(R.id.comment);
                this.textViewDate = (TextView) itemView.findViewById(R.id.person_age);
            }
        }

        @Override
        public ListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerlayout, parent, false);

            ViewHolder viewHolder = new ViewHolder(view);
            return viewHolder;
        }

        @Override
       /* public void onBindViewHolder(ListAdapter.ViewHolder holder, final int position)
        {   String x="You can't chase two rabbits";
            holder.textViewText.setText(dataList.get(position).getTitle());
           //holder.descrip.setText(x);
            holder.textViewDate.setText(dataList.get(position).getDate());

            holder.itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    Toast.makeText(getActivity(), "Item " + position + " is clicked.", Toast.LENGTH_SHORT).show();
                }
            });
        }*/

        public void onBindViewHolder(ListAdapter.ViewHolder holder, final int position)
       {
//        holder.date_picker.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(getActivity(), pickadate.class);
//
//
//                startActivity(i);
//                getActivity().overridePendingTransition(0, 0);
//            }
        //});
            holder.edit_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getActivity(), Edittask.class);
                    i.putExtra("mtitle",dataList.get(position).getTitle());
                    i.putExtra("mdes",dataList.get(position).getDescription());
                    i.putExtra("mdate",dataList.get(position).getDate());
                    String tab=dataList.get(position).getTable();
                    i.putExtra("mtable",tab);
                    startActivity(i);
                    getActivity().overridePendingTransition(0, 0);
                }
            });
            final boolean isExpanded = position==mExpandedPosition;
            holder.textViewComment.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.edit_btn.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.hier.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.textViewText.setText(dataList.get(position).getTitle());
            holder.textViewComment.setText(dataList.get(position).getDescription());
            holder.textViewDate.setText(dataList.get(position).getDate());
            holder.hier.setText(dataList.get(position).getPath());
            holder.itemView.setActivated(isExpanded);
            if (isExpanded)
                Global.previousExpandedPosition = position;
            holder.itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    mExpandedPosition = isExpanded ? -1:position;

                    //TransitionManager.beginDelayedTransition(getActivity());
                    notifyItemChanged(Global.previousExpandedPosition);
                    notifyItemChanged(position);//
                    //Toast.makeText(getActivity(), "Item " + position + " is clicked.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount()
        {
            return dataList.size();
        }
    }

}