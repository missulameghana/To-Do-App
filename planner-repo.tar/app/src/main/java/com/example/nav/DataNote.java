package com.example.nav;

import java.util.ArrayList;

public class DataNote {
    String title;
    ArrayList<String> subtask;
    ArrayList<Integer> subtask_id;
    String description;
    String date;
    String path;
    String table;

    public DataNote(String text, String comment, String date,ArrayList<String> subtask,ArrayList<Integer> subtask_id)
    {
        this.title = text;
        this.description = comment;
        this.date = date;
        this.subtask=subtask;
        this.subtask_id=subtask_id;
    }
    public DataNote(String text, String comment, String date, String path, String table){
        this.title = text;
        this.description = comment;
        this.date = date;
        this.path=path;
        this.table=table;
    }


    public String getTitle()
    {
        return title;
    }
    public String getPath()
    {
        return path;
    }
    public String getTable()
    {
        return table;
    }
    public String getDescription()
    {
        return description;
    }

    public String getDate()
    {
        return date;
    }
    public ArrayList<String> getSubtask()
    {
        return subtask;
    }
    public ArrayList<Integer> getSubtask_id()
    {
        return subtask_id;
    }
}
