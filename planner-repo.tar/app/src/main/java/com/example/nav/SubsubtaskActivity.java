package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class SubsubtaskActivity extends AppCompatActivity {
    private String st;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subsubtask);
        Intent in = getIntent();
        final String str1 = in.getStringExtra("mtitle");
        final String str2 = in.getStringExtra("mdes");
        setTitle(str1);
        st= str1;
        //final String s3 = in.getStringExtra("mdate");
        // homeViewModel =
        //      ViewModelProviders.of(this).get(HomeViewModel.class);
        //View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = (TextView) findViewById(R.id.text_home);
        textView.setText(str2);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        //item1 = menu.findItem(R.id.action_settings);
//        MenuItem item=menu.findItem(R.id.gallery_settings);
//        item.setVisible(false);
        return true;
    }
    //    @Override
//    public void onPrepareOptionsMenu(Menu menu) {
//        MenuItem item=menu.findItem(R.id.gallery_settings);
//        if(item!=null)
//            item.setVisible(false);
//    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            Intent intent = new Intent(this,Addtask.class);
//            startActivity(intent);
        switch (item.getItemId()) {

            case R.id.action_settings:
                Intent intent = new Intent(this,Edittask.class);
                intent.putExtra("mtable","subtasks");
                intent.putExtra("mess",st);
                intent.putExtra("des","0");
                intent.putExtra("date",st);
                startActivity(intent);
                return true;
            case R.id.gallery_settings:
                //item.setVisible(false);
                return false;

            default:
                return super.onOptionsItemSelected(item);        }

        //return super.onOptionsItemSelected(item);
    }

}
