package com.example.nav;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
//import com.example.nav.ui.home.HomeFragment;
import com.example.nav.ui.home.HomeViewModel;

import java.util.ArrayList;
class Global{
    static int previousExpandedPosition = -1;
}
public class SubtaskActivity extends AppCompatActivity {
   // private HomeViewModel homeViewModel;
   private static final String TAG = SubtaskActivity.class.getSimpleName();
   // private TextView mTextViewEmpty;
    private RecyclerView mRecyclerView;
    private SubtaskActivity.ListAdapter mListadapter;
    private  String st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subtask);
        Intent in = getIntent();
        final String str1 = in.getStringExtra("mtitle");
        final String str2 = in.getStringExtra("mdes");
        st=str1;
        setTitle(str1);
        //final String s3 = in.getStringExtra("mdate");
       // homeViewModel =
          //      ViewModelProviders.of(this).get(HomeViewModel.class);
        //View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = (TextView) findViewById(R.id.text_home);
        textView.setText(str2);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
      //  mTextViewEmpty = (TextView) findViewById(R.id.text_home);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        DbHelper mHelper=new DbHelper(this);
        SQLiteDatabase db = mHelper.getWritableDatabase();
//        String [] columns={Dbtasks.MenuEntry._ID,"name","description","scheduled"};
//        Cursor cursor=db.query("subtasks",columns,null,null,null,null,null);
        String[] columns={Dbtasks.MenuEntry._ID};
        Cursor cursor=db.query(Dbtasks.MenuEntry.TABLE1,columns,Dbtasks.MenuEntry.COLUMN_NAME+"= ?",new String[]{str1},null,null,null);
        cursor.moveToNext();
        int index2;
        index2 = cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
        Integer id=cursor.getInt(index2);
        Log.d(TAG,String.valueOf(id));
        String [] columnssub={"name","description","scheduled"};
        Cursor cursor2=db.query("subtasks",columnssub,Dbtasks.MenuEntry.TASK_ID + "=" + id,null,null,null,null);

        ArrayList data = new ArrayList<DataNote>();
        while(cursor2.moveToNext()) {
            Log.d(TAG,"Inside");
//            int index;
//            index = cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
//            Integer id = cursor.getInt(index);
           ArrayList<String> subtask=new ArrayList<>();
           ArrayList<Integer> subtask_id=new ArrayList<>();
//            String [] columnssub={Dbtasks.MenuEntry._ID,"name"};
//            Cursor cursor2=db.query("subtasks",columnssub,Dbtasks.MenuEntry.TASK_ID + "=" + id,null,null,null,null);
           /* while(cursor2.moveToNext()){
                int index2;
                index2 = cursor2.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
                subtask_id.add(cursor2.getInt(index2));
                index2 = cursor2.getColumnIndexOrThrow("name");
                subtask.add(cursor2.getString(index2));

            }*/
            //cursor2.close();
            int index;
            index = cursor2.getColumnIndexOrThrow("name");
            String title = cursor2.getString(index);
            Log.d(TAG,title);
            index = cursor2.getColumnIndexOrThrow("description");
            String description = cursor2.getString(index);

            index = cursor2.getColumnIndexOrThrow("scheduled");
            String date = cursor2.getString(index);

            data.add(new DataNote(title,description,date,subtask,subtask_id));

            //... do something with data
        }
        cursor2.close();
        cursor.close();
        // RecyclerView rv = (RecyclerView)findViewById(R.id.rv);
//        homeViewModel.getText().observe(this, new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });


            Log.d(TAG,"lfdjsk");

        mListadapter = new SubtaskActivity.ListAdapter(data);
        mRecyclerView.setAdapter(mListadapter);
        //return root;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        //item1 = menu.findItem(R.id.action_settings);
//        MenuItem item=menu.findItem(R.id.gallery_settings);
//        item.setVisible(false);
        return true;
    }
    //    @Override
//    public void onPrepareOptionsMenu(Menu menu) {
//        MenuItem item=menu.findItem(R.id.gallery_settings);
//        if(item!=null)
//            item.setVisible(false);
//    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            Intent intent = new Intent(this,Addtask.class);
//            startActivity(intent);
        switch (item.getItemId()) {

            case R.id.action_settings:
                Intent intent = new Intent(this,Addtask.class);
                intent.putExtra("mtable","subtasks");
                intent.putExtra("mess",st);
                startActivity(intent);
                return true;
            case R.id.gallery_settings:
                //item.setVisible(false);
                return false;

            default:
                return super.onOptionsItemSelected(item);        }

        //return super.onOptionsItemSelected(item);
    }

    public class ListAdapter extends RecyclerView.Adapter<SubtaskActivity.ListAdapter.ViewHolder>
    {
        private ArrayList<DataNote> dataList;
        private int mExpandedPosition=-1;
        int number_of_clicks = 0;
        boolean thread_started = false;
        final int DELAY_BETWEEN_CLICKS_IN_MILLISECONDS = 250;
        //private String description;
        public ListAdapter(ArrayList<DataNote> d)
        {
            this.dataList = d;
        }

        public class ViewHolder extends RecyclerView.ViewHolder
        {
            TextView textViewText;
            //TextView description;
            TextView textViewComment;
            TextView textViewDate;
            //ListView listView;

            Button edit_btn;

            public ViewHolder(View itemView)
            {
                super(itemView);
                this.textViewText = (TextView) itemView.findViewById(R.id.person_name);
                //this.listView = (ListView) itemView.findViewById(R.id.listView);
                this.edit_btn = (Button) itemView.findViewById(R.id.edit);


                // this.descrip= (TextView) itemView.findViewById(R.id.text_home);
                this.textViewComment = (TextView) itemView.findViewById(R.id.comment);
                this.textViewDate = (TextView) itemView.findViewById(R.id.person_age);
            }
        }

        @Override
        public SubtaskActivity.ListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerlayout, parent, false);

            SubtaskActivity.ListAdapter.ViewHolder viewHolder = new SubtaskActivity.ListAdapter.ViewHolder(view);
            return viewHolder;
        }

        @Override
       /* public void onBindViewHolder(ListAdapter.ViewHolder holder, final int position)
        {   String x="You can't chase two rabbits";
            holder.textViewText.setText(dataList.get(position).getTitle());
           //holder.descrip.setText(x);
            holder.textViewDate.setText(dataList.get(position).getDate());

            holder.itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    Toast.makeText(getActivity(), "Item " + position + " is clicked.", Toast.LENGTH_SHORT).show();
                }
            });
        }*/

        public void onBindViewHolder(SubtaskActivity.ListAdapter.ViewHolder holder, final int position)
        {  // String[] listofrandom= {"fjd","hf","shfd"};
            holder.edit_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(SubtaskActivity.this, Edittask.class);
                    i.putExtra("mtable","subtasks");
                    i.putExtra("mtitle",dataList.get(position).getTitle());
                    i.putExtra("mdes",dataList.get(position).getDescription());
                    i.putExtra("mdate",dataList.get(position).getDate());

                    startActivity(i);
                    SubtaskActivity.this.overridePendingTransition(0, 0);
                }
            });
            final boolean isExpanded = position==mExpandedPosition;
            holder.textViewComment.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            //holder.listView.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.edit_btn.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.textViewText.setText(dataList.get(position).getTitle());
            holder.textViewComment.setText(dataList.get(position).getDescription());
            holder.textViewDate.setText(dataList.get(position).getDate());
//            ArrayAdapter<String> ada=new ArrayAdapter<String>(
//                    getActivity(), R.layout.text_helper, dataList.get(position).getSubtask());
            //holder.listView.setAdapter(ada);
            holder.itemView.setActivated(isExpanded);
            if (isExpanded)
                Global.previousExpandedPosition = position;

            holder.itemView.setOnClickListener(new DoubleClickListener() {
                @Override
                public void onDoubleClick() {
                    Log.i("onClick", "double");
//                    GalleryFragment frag =new GalleryFragment();
//                    FragmentTransaction trans=getFragmentManager().beginTransaction();
//                    trans.replace(R.id.container_layout,frag);
//                    trans.commit();
                    //
                    //
                    // Activity act=SlideshowFragment.getActivity();
//                    Intent i = new Intent(this, SubtaskActivity.class);
//                    startActivity(i);
                    Intent i = new Intent(SubtaskActivity.this, SubsubtaskActivity.class);
                    i.putExtra("mtitle",dataList.get(position).getTitle());
                    i.putExtra("mdes",dataList.get(position).getDescription());
                    //  i.putExtra("mdate",dataList.get(position).getDate());
                    startActivity(i);
                    SubtaskActivity.this.overridePendingTransition(0, 0);
                }

                @Override
                public void onSingleClick() {
                    mExpandedPosition = isExpanded ? -1:position;

                    //TransitionManager.beginDelayedTransition(getActivity());
                    notifyItemChanged(Global.previousExpandedPosition);
                    notifyItemChanged(position);//
                }
            });
//            holder.itemView.setOnClickListener(new View.OnClickListener()
//            {
//                @Override
//                public void onClick(View v)
//                {
//                    mExpandedPosition = isExpanded ? -1:position;
//
//                    //TransitionManager.beginDelayedTransition(getActivity());
//                    notifyItemChanged(Global.previousExpandedPosition);
//                    notifyItemChanged(position);//
            //Toast.makeText(getActivity(), "Item " + position + " is clicked.", Toast.LENGTH_SHORT).show();
//                }
//            });
        }

        @Override
        public int getItemCount()
        {
            return dataList.size();
        }
    }
}
