package com.example.nav;


import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;


public class Dbtasks {

    public static final String CONTENT_AUTHORITY = "com.example.nav.ui.home";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    private static final String PATH_ENTRIES = "entries";

    public static class MenuEntry implements BaseColumns {

        public static final String CONTENT_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/vnd.home.entries";

        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/vnd.home.entry";

        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(PATH_ENTRIES).build();

        public static final String TABLE1 = "tasks";
        public static final String TABLE2 = "subtasks";
        public static final String TASK_ID = "task_id";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_DESCRIPTION = "description";
        public static final String COLUMN_SCHEDULED = "scheduled";


    }
}