package com.example.nav.ui.home;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.TransitionManager;

import com.example.nav.Addtask;
import com.example.nav.DataNote;
import com.example.nav.DbHelper;
import com.example.nav.Dbtasks;
import com.example.nav.DoubleClickListener;
import com.example.nav.Edittask;
import com.example.nav.MainActivity;
import com.example.nav.R;
import com.example.nav.SubtaskActivity;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

class Global{
    static int previousExpandedPosition = -1;
}
public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;

    private TextView mTextViewEmpty;
    private RecyclerView mRecyclerView;
    private ListAdapter mListadapter;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        mRecyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);
        mTextViewEmpty = (TextView)root.findViewById(R.id.text_home);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        DbHelper mHelper=new DbHelper(getActivity());
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String [] columns={Dbtasks.MenuEntry._ID,"name","description","scheduled"};
        Cursor cursor=db.query("tasks",columns,null,null,null,null,null);
        ArrayList data = new ArrayList<DataNote>();
        while(cursor.moveToNext()) {
            int index;
            index = cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
            Integer id = cursor.getInt(index);
            ArrayList<String> subtask=new ArrayList<>();
            ArrayList<Integer> subtask_id=new ArrayList<>();
            String [] columnssub={Dbtasks.MenuEntry._ID,"name"};
            Cursor cursor2=db.query("subtasks",columnssub,Dbtasks.MenuEntry.TASK_ID + "=" + id,null,null,null,null);
            while(cursor2.moveToNext()){
                int index2;
                index2 = cursor2.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
                subtask_id.add(cursor2.getInt(index2));
                index2 = cursor2.getColumnIndexOrThrow("name");
                subtask.add(cursor2.getString(index2));

            }
            cursor2.close();
            index = cursor.getColumnIndexOrThrow("name");
            String title = cursor.getString(index);

            index = cursor.getColumnIndexOrThrow("description");
            String description = cursor.getString(index);

            index = cursor.getColumnIndexOrThrow("scheduled");
            String date = cursor.getString(index);

            data.add(new DataNote(title,description,date,subtask,subtask_id));

            //... do something with data
        }
        cursor.close();
        // RecyclerView rv = (RecyclerView)findViewById(R.id.rv);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        mListadapter = new ListAdapter(data);
        mRecyclerView.setAdapter(mListadapter);
        return root;
    }

    public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder>
    {
        private ArrayList<DataNote> dataList;
        private int mExpandedPosition=-1;

        //private String description;
        public ListAdapter(ArrayList<DataNote> data)
        {
            this.dataList = data;
        }

        public class ViewHolder extends RecyclerView.ViewHolder
        {
            TextView textViewText;
            //TextView description;
            TextView textViewComment;
            TextView textViewDate;
            ListView listView;

            Button edit_btn;

            public ViewHolder(View itemView)
            {
                super(itemView);
                this.textViewText = (TextView) itemView.findViewById(R.id.person_name);
                this.listView = (ListView) itemView.findViewById(R.id.listView);
                this.edit_btn = (Button) itemView.findViewById(R.id.edit);


                // this.descrip= (TextView) itemView.findViewById(R.id.text_home);
                this.textViewComment = (TextView) itemView.findViewById(R.id.comment);
                this.textViewDate = (TextView) itemView.findViewById(R.id.person_age);
            }
        }

        @Override
        public ListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerlayout, parent, false);

            ViewHolder viewHolder = new ViewHolder(view);
            return viewHolder;
        }

        @Override
       /* public void onBindViewHolder(ListAdapter.ViewHolder holder, final int position)
        {   String x="You can't chase two rabbits";
            holder.textViewText.setText(dataList.get(position).getTitle());
           //holder.descrip.setText(x);
            holder.textViewDate.setText(dataList.get(position).getDate());

            holder.itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    Toast.makeText(getActivity(), "Item " + position + " is clicked.", Toast.LENGTH_SHORT).show();
                }
            });
        }*/

        public void onBindViewHolder(ListAdapter.ViewHolder holder, final int position)
        {  // String[] listofrandom= {"fjd","hf","shfd"};
            holder.edit_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getActivity(), Edittask.class);
                    i.putExtra("mtitle",dataList.get(position).getTitle());
                    i.putExtra("mdes",dataList.get(position).getDescription());
                    i.putExtra("mdate",dataList.get(position).getDate());
                    i.putExtra("mtable","tasks");

                    startActivity(i);
                    getActivity().overridePendingTransition(0, 0);
                }
            });
            final boolean isExpanded = position==mExpandedPosition;
            //holder.listView.setEnabled(false);
            holder.textViewComment.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.listView.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.edit_btn.setVisibility(isExpanded?View.VISIBLE:View.GONE);
            holder.textViewText.setText(dataList.get(position).getTitle());
            holder.textViewComment.setText(dataList.get(position).getDescription());
            holder.textViewDate.setText(dataList.get(position).getDate());
            ArrayAdapter<String> ada=new ArrayAdapter<String>(
                    getActivity(), R.layout.text_helper, dataList.get(position).getSubtask());

            holder.listView.setAdapter(ada);
            holder.itemView.setActivated(isExpanded);
            if (isExpanded)
                Global.previousExpandedPosition = position;
            holder.itemView.setOnClickListener(new DoubleClickListener() {
                @Override
                public void onDoubleClick() {
                    Log.i("onClick", "double");
//                    GalleryFragment frag =new GalleryFragment();
//                    FragmentTransaction trans=getFragmentManager().beginTransaction();
//                    trans.replace(R.id.container_layout,frag);
//                    trans.commit();
                    //
                    //
                    // Activity act=SlideshowFragment.getActivity();
                    Intent i = new Intent(getActivity() , SubtaskActivity.class);
                    i.putExtra("mtitle",dataList.get(position).getTitle());
                    i.putExtra("mdes",dataList.get(position).getDescription());
                    //  i.putExtra("mdate",dataList.get(position).getDate());
                    startActivity(i);
                    getActivity().overridePendingTransition(0, 0);
                }

                @Override
                public void onSingleClick() {
                    mExpandedPosition = isExpanded ? -1:position;

                    //TransitionManager.beginDelayedTransition(getActivity());
                    notifyItemChanged(Global.previousExpandedPosition);
                    notifyItemChanged(position);//
                }
            });
        }

        @Override
        public int getItemCount()
        {
            return dataList.size();
        }
    }

}