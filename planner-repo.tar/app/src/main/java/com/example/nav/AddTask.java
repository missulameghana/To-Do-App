package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.nav.ui.addtask.AddTaskFragment;

public class AddTask extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_task_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, AddTaskFragment.newInstance())
                    .commitNow();
        }
    }
}
