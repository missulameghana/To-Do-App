package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.nav.ui.gallery.GalleryFragment;
import com.example.nav.ui.gallery.GalleryFragment_edit;
import com.example.nav.ui.home.HomeFragment;

import java.util.Calendar;

public class pickadate extends AppCompatActivity  implements
        View.OnClickListener

{
    private static final String TAG = "pickadate";
    //private DbHelper mHelper;
    public static Button btnDatePicker;
            //, savebutton;
    //EditText taskEditText_title,taskEditText_des;
    String txtDate;
    private int mYear, mMonth, mDay;
    public static pickadate fa;
    //public static Button ab=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datelay);
        fa=this;
        setTitle("DayView");

//        mHelper = new DbHelper(this);
//        savebutton=(Button) findViewById(R.id.save);
        btnDatePicker=(Button)findViewById(R.id.btn_date);
        btnDatePicker.setOnClickListener(this);}
        //txtDate=new TextView(this);
//        final Calendar c = Calendar.getInstance();
//        mYear = c.get(Calendar.YEAR);
//        mMonth = c.get(Calendar.MONTH);
//        mDay = c.get(Calendar.DAY_OF_MONTH);
//
//
//        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
//                new DatePickerDialog.OnDateSetListener() {
//
//                    @Override
//                    public void onDateSet(DatePicker view, int year,
//                                          int monthOfYear, int dayOfMonth) {
//
//                        txtDate = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
//                        Intent i = new Intent(pickadate.this , GalleryFragment.class);
//                        i.putExtra("picked date",txtDate);
//                        startActivity(i);
//
//                    }
//                }, mYear, mMonth, mDay);
//        datePickerDialog.show();
//
//        //txtDate = (TextView) findViewById(R.id.date);
//        btnDatePicker.setOnClickListener(this);
//        savebutton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                taskEditText_title = (EditText) findViewById(R.id.title);
//                taskEditText_des = (EditText) findViewById(R.id.des);
//                //Intent intent1 = new Intent(this,MainActivity.class);
//                // startActivity(intent1);
//                if( taskEditText_title.getText().toString().length() == 0 )
//                    taskEditText_title.setError( "Task name is required!" );
//
//                else{
//                    String title = String.valueOf(taskEditText_title.getText());
//                    String des= String.valueOf(taskEditText_des.getText());
//                    String date= String.valueOf(txtDate.getText());
//                    SQLiteDatabase db = mHelper.getWritableDatabase();
//
//                    ContentValues values = new ContentValues();
//                    // values.put(Dbtasks.MenuEntry._ID, 5);
//                    values.put(Dbtasks.MenuEntry.COLUMN_NAME, title);
//                    values.put(Dbtasks.MenuEntry.COLUMN_DESCRIPTION, des);
//                    values.put(Dbtasks.MenuEntry.COLUMN_SCHEDULED, date);
//
//
//                    db.insertWithOnConflict(Dbtasks.MenuEntry.TABLE1,null,values, SQLiteDatabase.CONFLICT_REPLACE);
//                    db.close();
//
//
//                    Intent i = new Intent(pickadate.this , GalleryFragment.getActivity());
//                    startActivity(i);
//
//                }}
//        });
        //layout.addView(txtDate);
        //layout.addView(btnDatePicker);
        //setContentView(layout);



    @Override
    public void onClick(View v) {

        Log.d(TAG,"urkey");
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        txtDate=dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
//                        Intent i = new Intent(pickadate.this , GalleryFragment_edit.class);
//                        i.putExtra("picked date",txtDate);
//                        startActivity(i);
                        GalleryFragment_edit fragment = new GalleryFragment_edit();
                        Bundle arguments = new Bundle();
                        arguments.putString( "picked date",txtDate);
                        fragment.setArguments(arguments);
                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.container_layout, fragment);
                        transaction.commit();
                        //finish();

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }
}
