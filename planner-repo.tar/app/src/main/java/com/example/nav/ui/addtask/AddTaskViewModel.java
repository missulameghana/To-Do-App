package com.example.nav.ui.addtask;

import androidx.lifecycle.ViewModel;

public class AddTaskViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
