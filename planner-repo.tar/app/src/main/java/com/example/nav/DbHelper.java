package com.example.nav;

import android.content.Context;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DbHelper extends SQLiteOpenHelper {
    private static final String TAG = DbHelper.class.getSimpleName();

    private Resources mResources;
    private static final String DATABASE_NAME = "menu.db";
    private static final int DATABASE_VERSION = 1;
    Context context;
    SQLiteDatabase db;


    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

        mResources = context.getResources();

        db = this.getWritableDatabase();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        final String SQL_CREATE_BUGS_TABLE1 = "CREATE TABLE " + Dbtasks.MenuEntry.TABLE1 + " (" +
                Dbtasks.MenuEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                Dbtasks.MenuEntry.COLUMN_NAME + " TEXT , " +
                Dbtasks.MenuEntry.COLUMN_DESCRIPTION + " TEXT , " +
                Dbtasks.MenuEntry.COLUMN_SCHEDULED + " TEXT " + " );";
        final String SQL_CREATE_BUGS_TABLE2 = "CREATE TABLE " + Dbtasks.MenuEntry.TABLE2 + " (" +
                Dbtasks.MenuEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT ," +
                Dbtasks.MenuEntry.TASK_ID + " INTEGER ," +
                Dbtasks.MenuEntry.COLUMN_NAME + " TEXT , " +
                Dbtasks.MenuEntry.COLUMN_DESCRIPTION + " TEXT, " +
                Dbtasks.MenuEntry.COLUMN_SCHEDULED + " TEXT, " +
                "FOREIGN KEY ("+Dbtasks.MenuEntry.TASK_ID+") REFERENCES "+ Dbtasks.MenuEntry.TABLE1+
                "("+ Dbtasks.MenuEntry._ID+") "+");";


        db.execSQL(SQL_CREATE_BUGS_TABLE1);
        db.execSQL(SQL_CREATE_BUGS_TABLE2);
        Log.d(TAG, "Database Created Successfully" );
        readDataToDb(db);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    private void readDataToDb(SQLiteDatabase db){
        db.execSQL("INSERT INTO tasks ("+Dbtasks.MenuEntry._ID+",name,description,scheduled)"+
                "VALUES (1, 'Acads', 'Padhai ki baatein', '31-12-2019');");

        db.execSQL("INSERT INTO tasks ("+Dbtasks.MenuEntry._ID+",name,description,scheduled)"+
                "VALUES (2, 'Self improvement', 'Reading list, blogs, exercise, etc.', '30-12-2019');");

        db.execSQL("INSERT INTO tasks ("+Dbtasks.MenuEntry._ID+",name,description,scheduled)"+
                "VALUES (3, 'Research', 'Pet projects', null);");

        db.execSQL("INSERT INTO tasks ("+Dbtasks.MenuEntry._ID+",name,description,scheduled)"+
                "VALUES (4, 'Hobbies', '<3', null);");
        db.execSQL("INSERT INTO subtasks ("+Dbtasks.MenuEntry._ID+",task_id,name,description,scheduled)"+
                "VALUES (1,2,'Excercise','someday?', '29-2-2021');");

        db.execSQL("INSERT INTO subtasks ("+Dbtasks.MenuEntry._ID+",task_id,name,description,scheduled)"+
                "VALUES (2,2,'Reading list','My bucket list:\nHear the Wind Sing\nThe Fountainhead\nAtlas Shrugged\nA prisoner of birth', null);");

        db.execSQL("INSERT INTO subtasks ("+Dbtasks.MenuEntry._ID+",task_id,name,description,scheduled)"+
                "VALUES (3,4,'Origami','cranes and tigers.', '29-10-2019');");

        db.execSQL("INSERT INTO subtasks ("+Dbtasks.MenuEntry._ID+",task_id,name,description,scheduled)"+
                " VALUES (4,4,'Drum practice!','Aim:\nHallowed be thy name,\nAcid Rain (LTE)', '29-10-2019');");
    }

}
