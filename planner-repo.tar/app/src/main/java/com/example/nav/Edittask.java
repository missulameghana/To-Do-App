package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.nav.ui.home.HomeFragment;

import java.util.Calendar;

public class Edittask extends AppCompatActivity
        implements
        View.OnClickListener
{
    private DbHelper mHelper;
    Button btnDatePicker, savebutton;
    EditText taskEditText_title,taskEditText_des;
    TextView txtDate;
    private static final String TAG = "Edittask";
    private int mYear, mMonth, mDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addlay);
        Intent in = getIntent();
        final String s1 = in.getStringExtra("mtitle");
        final String s2 = in.getStringExtra("mdes");
        final String s3 = in.getStringExtra("mdate");
        final String s4 = in.getStringExtra("mtable");
        /*super.onCreate(savedInstanceState);
        setContentView(R.layout.addlay);*/
        mHelper = new DbHelper(this);
        savebutton=(Button) findViewById(R.id.save);
        btnDatePicker=(Button)findViewById(R.id.btn_date);
        txtDate=new TextView(this);
        txtDate = (TextView) findViewById(R.id.date);
        txtDate.setText(s3);
        btnDatePicker.setOnClickListener(this);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskEditText_title = (EditText) findViewById(R.id.title);
                //taskEditText_title.setText(s1);
                taskEditText_des = (EditText) findViewById(R.id.des);
                //taskEditText_des.setText(s2);
                //Intent intent1 = new Intent(this,MainActivity.class);
                // startActivity(intent1);
                if( taskEditText_title.getText().toString().length() == 0 )
                    taskEditText_title.setError( "Task name is required!" );

                else{
                    String title = String.valueOf(taskEditText_title.getText());
                    String des= String.valueOf(taskEditText_des.getText());
                    String date= String.valueOf(txtDate.getText());
                    SQLiteDatabase db = mHelper.getWritableDatabase();

                    ContentValues values = new ContentValues();
                    //values.put(Dbtasks.MenuEntry._ID, 5);
                    values.put(Dbtasks.MenuEntry.COLUMN_NAME, title);
                    values.put(Dbtasks.MenuEntry.COLUMN_DESCRIPTION, des);
                    values.put(Dbtasks.MenuEntry.COLUMN_SCHEDULED, date);

                   //String[] columns={Dbtasks.MenuEntry._ID};
                   // Cursor cursor=db.query(Dbtasks.MenuEntry.TABLE1,columns,Dbtasks.MenuEntry.COLUMN_NAME+"= ?",new String[]{s1},null,null,null);
                    //cursor.moveToNext();
                    //int index2;
                    //index2 = cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry._ID);
                    //int indx = cursor.getInt(index2);
                    //db.update("tasks",values,Dbtasks.MenuEntry._ID+"="+index2,null);
                    if(s4.equals("tasks")){
                    db.execSQL("UPDATE "+Dbtasks.MenuEntry.TABLE1+" SET name = '"+title+"' ,description= '"+des+"' ,scheduled= '"+date+"' WHERE name= '"+s1+"' ;  ");}
                    else if (s4.equals("subtasks")){
                        
                        db.execSQL("UPDATE "+s4+" SET name = '"+title+"' ,description= '"+des+"' ,scheduled= '"+date+"' WHERE name= '"+s1+"' ;  ");
                    }
//                   String[] columns2={Dbtasks.MenuEntry._ID,Dbtasks.MenuEntry.COLUMN_NAME};
//                    cursor=db.query(Dbtasks.MenuEntry.TABLE1,columns2,Dbtasks.MenuEntry._ID+"="+indx,null,null,null,null);
//                    cursor.moveToNext();
//                    index2=cursor.getColumnIndexOrThrow(Dbtasks.MenuEntry.COLUMN_NAME);
//                    Log.d(TAG,title);
//                    Log.d(TAG,cursor.getString(index2));
                    //db.insertWithOnConflict(Dbtasks.MenuEntry.TABLE1,null,values, SQLiteDatabase.CONFLICT_REPLACE);
                    db.close();
                   // cursor.close();


                    Intent i = new Intent(Edittask.this , MainActivity.class);
                    startActivity(i);

                }}
        });
        //layout.addView(txtDate);
        //layout.addView(btnDatePicker);
        //setContentView(layout);


    }
    @Override
    public void onClick(View v) {


        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }
}
